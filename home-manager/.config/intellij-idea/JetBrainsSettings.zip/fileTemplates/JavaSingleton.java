package ${PACKAGE_NAME};

import org.jetbrains.annotations.NotNull;

public class ${NAME} {

    private static ${NAME} instance;

    private ${NAME}() {

    }

    @NotNull
    public static ${NAME} get() {
        if (instance == null) {
            instance = new ${NAME}();
        }

        return instance;
    }
}